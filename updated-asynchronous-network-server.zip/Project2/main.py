from aiohttp import web
import os
import random
import string
import logging
import asyncio

# Handles each HTTP request and reads in the contents of each text file that is requested
async def handle(request):
    name = request.match_info.get('name', "Anonymous")
    f = open(name, "r")
    return web.Response(text=f.read())


async def apprun(host='localhost', port=8080):
    # Starts a new web application on the localhost8080
    app = web.Application()
    app.add_routes([web.get('/', handle),
                    web.get("/{name}", handle)])
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host=host, port=port)
    await site.start()

    # Prints message to console to notify user where HTTP requests are being served
    print(f"Hosting app on localhost:8080")
    return runner, site


# The main function of the program
if __name__ == '__main__':

    # Generates 100 text files
    for i in range(100):
        open('file%s.txt' % i, 'r').close()

    dirname = os.path.dirname(__file__)

    # Randomly generates contents of files
    for filename in os.listdir(dirname):
        chars = ''.join([random.choice(string.ascii_letters) for i in range(10000)])
        if filename.endswith(".txt"):
            filename = open(filename, 'w').write(chars)
        else:
            continue

    # Creates a default logger that prints to the console for each HTTP request
    logging.basicConfig(level=logging.DEBUG)

    # Gets the event loop that will run asynchronous tasks
    loop = asyncio.get_event_loop()

    # Creates a new asynchronous task of apprun()
    task = loop.create_task(apprun())

    # Will run the event loop until the async task is complete
    runner, site = loop.run_until_complete(task)

    # Will continue to accept incoming HTTP requests until the user decides to termiante program
    loop.run_forever()
